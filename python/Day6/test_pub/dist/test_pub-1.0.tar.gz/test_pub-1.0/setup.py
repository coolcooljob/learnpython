from distutils.core import setup

setup(name='test_pub',version='1.0',author='Job',py_modules=['my_package.module1'])
